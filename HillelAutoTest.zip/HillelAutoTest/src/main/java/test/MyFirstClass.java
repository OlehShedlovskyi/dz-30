package test;

public class MyFirstClass {
    public static void main(String[] args) {
        int a = 5;
        int b = 10;
        int c = 32;
        int d =a+c-b;
        System.out.println("The result is   " +d);
    }
}
